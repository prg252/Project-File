﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightApp
{
    public partial class Form1 : Form
    {
        DataHandling dh = new DataHandling();
        BindingSource bs = new BindingSource();
        public Form1()
        {
            InitializeComponent();
        }

        BindingSource bsFlightSimulator = new BindingSource();
        private void Form1_Load(object sender, EventArgs e)
        {
            DataHandling handler = new DataHandling();
            FlightDetails flight = new FlightDetails();
            bsFlightSimulator.DataSource = flight.GetFlight();
            dataGridView1.DataSource = bsFlightSimulator;

           

        }

    
    }
}
